#!/bin/bash
mkdir tools
wget https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.2.4.jar -O tools/apktool.jar