disable_lua = false

dofile('dji-p3.lua')
