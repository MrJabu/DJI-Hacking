package com.darksimpson.jdjitools;

public class JDTException extends Exception {
	public JDTException(String message) {
		super(message);
	}

	public JDTException() {
		super();
	}
}
