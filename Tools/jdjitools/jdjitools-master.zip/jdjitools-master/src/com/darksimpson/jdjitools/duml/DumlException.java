package com.darksimpson.jdjitools.duml;

public class DumlException extends Exception {
	public DumlException(String message) {
		super(message);
	}

	public DumlException() {
		super();
	}
}
