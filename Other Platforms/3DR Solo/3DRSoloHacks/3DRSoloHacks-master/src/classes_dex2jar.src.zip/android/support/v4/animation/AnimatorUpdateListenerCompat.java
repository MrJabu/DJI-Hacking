package android.support.v4.animation;

public abstract interface AnimatorUpdateListenerCompat
{
  public abstract void onAnimationUpdate(ValueAnimatorCompat paramValueAnimatorCompat);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.animation.AnimatorUpdateListenerCompat
 * JD-Core Version:    0.6.2
 */