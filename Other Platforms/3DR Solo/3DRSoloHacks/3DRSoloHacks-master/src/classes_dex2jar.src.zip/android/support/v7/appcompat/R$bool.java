package android.support.v7.appcompat;

public final class R$bool
{
  public static final int abc_action_bar_embed_tabs = 2131296258;
  public static final int abc_action_bar_embed_tabs_pre_jb = 2131296256;
  public static final int abc_action_bar_expanded_action_views_exclusive = 2131296259;
  public static final int abc_config_actionMenuItemAllCaps = 2131296260;
  public static final int abc_config_allowActionMenuItemTextWithIcon = 2131296257;
  public static final int abc_config_closeDialogWhenTouchOutside = 2131296261;
  public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2131296262;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.appcompat.R.bool
 * JD-Core Version:    0.6.2
 */