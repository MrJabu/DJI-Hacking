package android.support.v4.widget;

abstract interface DrawerLayoutImpl
{
  public abstract void setChildInsets(Object paramObject, boolean paramBoolean);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.DrawerLayoutImpl
 * JD-Core Version:    0.6.2
 */