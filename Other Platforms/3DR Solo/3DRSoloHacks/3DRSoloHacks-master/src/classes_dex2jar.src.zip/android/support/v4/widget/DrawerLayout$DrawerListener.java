package android.support.v4.widget;

import android.view.View;

public abstract interface DrawerLayout$DrawerListener
{
  public abstract void onDrawerClosed(View paramView);

  public abstract void onDrawerOpened(View paramView);

  public abstract void onDrawerSlide(View paramView, float paramFloat);

  public abstract void onDrawerStateChanged(int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.DrawerLayout.DrawerListener
 * JD-Core Version:    0.6.2
 */