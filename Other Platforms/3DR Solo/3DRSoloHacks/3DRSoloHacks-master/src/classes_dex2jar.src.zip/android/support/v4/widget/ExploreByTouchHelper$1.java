package android.support.v4.widget;

class ExploreByTouchHelper$1
{
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.ExploreByTouchHelper.1
 * JD-Core Version:    0.6.2
 */