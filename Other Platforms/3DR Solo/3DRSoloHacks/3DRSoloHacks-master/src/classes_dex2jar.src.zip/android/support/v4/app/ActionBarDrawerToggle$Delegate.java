package android.support.v4.app;

import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;

public abstract interface ActionBarDrawerToggle$Delegate
{
  @Nullable
  public abstract Drawable getThemeUpIndicator();

  public abstract void setActionBarDescription(@StringRes int paramInt);

  public abstract void setActionBarUpIndicator(Drawable paramDrawable, @StringRes int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ActionBarDrawerToggle.Delegate
 * JD-Core Version:    0.6.2
 */