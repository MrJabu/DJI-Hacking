package android.support.v4.view;

import android.view.MotionEvent;

class MotionEventCompatGingerbread
{
  public static int getSource(MotionEvent paramMotionEvent)
  {
    return paramMotionEvent.getSource();
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.MotionEventCompatGingerbread
 * JD-Core Version:    0.6.2
 */