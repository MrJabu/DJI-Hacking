package android.support.v7.appcompat;

public final class R$anim
{
  public static final int abc_fade_in = 2130968576;
  public static final int abc_fade_out = 2130968577;
  public static final int abc_grow_fade_in_from_bottom = 2130968578;
  public static final int abc_popup_enter = 2130968579;
  public static final int abc_popup_exit = 2130968580;
  public static final int abc_shrink_fade_out_from_bottom = 2130968581;
  public static final int abc_slide_in_bottom = 2130968582;
  public static final int abc_slide_in_top = 2130968583;
  public static final int abc_slide_out_bottom = 2130968584;
  public static final int abc_slide_out_top = 2130968585;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.appcompat.R.anim
 * JD-Core Version:    0.6.2
 */