package android.support.v4;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "android.support.v4";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = -1;
  public static final String VERSION_NAME = "";
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.BuildConfig
 * JD-Core Version:    0.6.2
 */