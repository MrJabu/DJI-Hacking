package android.support.v4.widget;

class DrawerLayout$ViewDragCallback$1
  implements Runnable
{
  DrawerLayout$ViewDragCallback$1(DrawerLayout.ViewDragCallback paramViewDragCallback)
  {
  }

  public void run()
  {
    DrawerLayout.ViewDragCallback.access$000(this.this$1);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.DrawerLayout.ViewDragCallback.1
 * JD-Core Version:    0.6.2
 */