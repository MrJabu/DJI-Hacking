package android.support.v4.widget;

class CursorAdapter$1
{
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.CursorAdapter.1
 * JD-Core Version:    0.6.2
 */