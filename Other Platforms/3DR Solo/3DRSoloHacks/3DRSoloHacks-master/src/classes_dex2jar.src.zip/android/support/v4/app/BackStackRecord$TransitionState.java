package android.support.v4.app;

import android.support.v4.util.ArrayMap;
import android.view.View;
import java.util.ArrayList;

public class BackStackRecord$TransitionState
{
  public FragmentTransitionCompat21.EpicenterView enteringEpicenterView = new FragmentTransitionCompat21.EpicenterView();
  public ArrayList<View> hiddenFragmentViews = new ArrayList();
  public ArrayMap<String, String> nameOverrides = new ArrayMap();
  public View nonExistentView;

  public BackStackRecord$TransitionState(BackStackRecord paramBackStackRecord)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.BackStackRecord.TransitionState
 * JD-Core Version:    0.6.2
 */