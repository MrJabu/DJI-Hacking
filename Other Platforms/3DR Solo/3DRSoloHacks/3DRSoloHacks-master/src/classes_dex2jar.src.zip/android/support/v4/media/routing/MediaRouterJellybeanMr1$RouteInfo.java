package android.support.v4.media.routing;

import android.media.MediaRouter.RouteInfo;
import android.view.Display;

public final class MediaRouterJellybeanMr1$RouteInfo
{
  public static Display getPresentationDisplay(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).getPresentationDisplay();
  }

  public static boolean isEnabled(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).isEnabled();
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.routing.MediaRouterJellybeanMr1.RouteInfo
 * JD-Core Version:    0.6.2
 */