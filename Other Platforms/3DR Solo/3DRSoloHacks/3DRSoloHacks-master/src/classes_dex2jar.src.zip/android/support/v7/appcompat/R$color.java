package android.support.v7.appcompat;

public final class R$color
{
  public static final int abc_background_cache_hint_selector_material_dark = 2131427436;
  public static final int abc_background_cache_hint_selector_material_light = 2131427437;
  public static final int abc_input_method_navigation_guard = 2131427328;
  public static final int abc_primary_text_disable_only_material_dark = 2131427438;
  public static final int abc_primary_text_disable_only_material_light = 2131427439;
  public static final int abc_primary_text_material_dark = 2131427440;
  public static final int abc_primary_text_material_light = 2131427441;
  public static final int abc_search_url_text = 2131427442;
  public static final int abc_search_url_text_normal = 2131427329;
  public static final int abc_search_url_text_pressed = 2131427330;
  public static final int abc_search_url_text_selected = 2131427331;
  public static final int abc_secondary_text_material_dark = 2131427443;
  public static final int abc_secondary_text_material_light = 2131427444;
  public static final int accent_material_dark = 2131427332;
  public static final int accent_material_light = 2131427333;
  public static final int background_floating_material_dark = 2131427334;
  public static final int background_floating_material_light = 2131427335;
  public static final int background_material_dark = 2131427336;
  public static final int background_material_light = 2131427337;
  public static final int bright_foreground_disabled_material_dark = 2131427339;
  public static final int bright_foreground_disabled_material_light = 2131427340;
  public static final int bright_foreground_inverse_material_dark = 2131427341;
  public static final int bright_foreground_inverse_material_light = 2131427342;
  public static final int bright_foreground_material_dark = 2131427343;
  public static final int bright_foreground_material_light = 2131427344;
  public static final int button_material_dark = 2131427345;
  public static final int button_material_light = 2131427346;
  public static final int dim_foreground_disabled_material_dark = 2131427374;
  public static final int dim_foreground_disabled_material_light = 2131427375;
  public static final int dim_foreground_material_dark = 2131427376;
  public static final int dim_foreground_material_light = 2131427377;
  public static final int highlighted_text_material_dark = 2131427381;
  public static final int highlighted_text_material_light = 2131427382;
  public static final int hint_foreground_material_dark = 2131427383;
  public static final int hint_foreground_material_light = 2131427384;
  public static final int link_text_material_dark = 2131427388;
  public static final int link_text_material_light = 2131427389;
  public static final int material_blue_grey_800 = 2131427390;
  public static final int material_blue_grey_900 = 2131427391;
  public static final int material_blue_grey_950 = 2131427392;
  public static final int material_deep_teal_200 = 2131427393;
  public static final int material_deep_teal_500 = 2131427394;
  public static final int primary_dark_material_dark = 2131427400;
  public static final int primary_dark_material_light = 2131427401;
  public static final int primary_material_dark = 2131427402;
  public static final int primary_material_light = 2131427403;
  public static final int primary_text_default_material_dark = 2131427405;
  public static final int primary_text_default_material_light = 2131427406;
  public static final int primary_text_disabled_material_dark = 2131427407;
  public static final int primary_text_disabled_material_light = 2131427408;
  public static final int ripple_material_dark = 2131427410;
  public static final int ripple_material_light = 2131427411;
  public static final int secondary_text_default_material_dark = 2131427413;
  public static final int secondary_text_default_material_light = 2131427414;
  public static final int secondary_text_disabled_material_dark = 2131427415;
  public static final int secondary_text_disabled_material_light = 2131427416;
  public static final int switch_thumb_disabled_material_dark = 2131427417;
  public static final int switch_thumb_disabled_material_light = 2131427418;
  public static final int switch_thumb_material_dark = 2131427450;
  public static final int switch_thumb_material_light = 2131427451;
  public static final int switch_thumb_normal_material_dark = 2131427419;
  public static final int switch_thumb_normal_material_light = 2131427420;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.appcompat.R.color
 * JD-Core Version:    0.6.2
 */