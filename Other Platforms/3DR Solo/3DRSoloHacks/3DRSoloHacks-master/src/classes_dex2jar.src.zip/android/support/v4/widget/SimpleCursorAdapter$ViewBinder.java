package android.support.v4.widget;

import android.database.Cursor;
import android.view.View;

public abstract interface SimpleCursorAdapter$ViewBinder
{
  public abstract boolean setViewValue(View paramView, Cursor paramCursor, int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SimpleCursorAdapter.ViewBinder
 * JD-Core Version:    0.6.2
 */