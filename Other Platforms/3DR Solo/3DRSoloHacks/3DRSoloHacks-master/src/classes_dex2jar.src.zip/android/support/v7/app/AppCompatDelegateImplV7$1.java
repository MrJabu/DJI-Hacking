package android.support.v7.app;

class AppCompatDelegateImplV7$1
  implements Runnable
{
  AppCompatDelegateImplV7$1(AppCompatDelegateImplV7 paramAppCompatDelegateImplV7)
  {
  }

  public void run()
  {
    if ((0x1 & AppCompatDelegateImplV7.access$000(this.this$0)) != 0)
      AppCompatDelegateImplV7.access$100(this.this$0, 0);
    if ((0x100 & AppCompatDelegateImplV7.access$000(this.this$0)) != 0)
      AppCompatDelegateImplV7.access$100(this.this$0, 8);
    AppCompatDelegateImplV7.access$202(this.this$0, false);
    AppCompatDelegateImplV7.access$002(this.this$0, 0);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.app.AppCompatDelegateImplV7.1
 * JD-Core Version:    0.6.2
 */