package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompatKitKat
{
  static int getAllocationByteCount(Bitmap paramBitmap)
  {
    return paramBitmap.getAllocationByteCount();
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.graphics.BitmapCompatKitKat
 * JD-Core Version:    0.6.2
 */